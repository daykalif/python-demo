"""
包：
    包是一个包含多个模块的特殊目录
    目录下有一个特殊的文件__init__.py
    包名的命名方式和变量名一致，小写字母+_
"""

from . import send_message
from . import receive_message
